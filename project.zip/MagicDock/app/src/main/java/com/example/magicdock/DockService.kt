package com.example.magicdock

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.*
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.util.DisplayMetrics
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.animation.OvershootInterpolator
import android.widget.*
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation

fun startDock(c: Context, code: Int = 0, data: Intent? = null) {
    val i = Intent(c, DockService::class.java)
    if (data != null) i.putExtra("code", code).putExtra("data", data)
    if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (c.getSharedPreferences("dock", 0).getBoolean("on", false) && Settings.canDrawOverlays(c)) startDock(c)
    }
}

class DockService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private var trigger: View? = null
    private var panel: FrameLayout? = null
    private var pill: View? = null
    private var spr: SpringAnimation? = null
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var held: Image? = null
    private val cap = 4

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    @Suppress("DEPRECATION")
    private fun type() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("dock", MODE_PRIVATE)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("dock", "Magic Dock", NotificationManager.IMPORTANCE_MIN))
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "dock") else Notification.Builder(this)
        b.setContentTitle("Magic Dock is on").setContentText("Swipe up along the screen edge")
            .setSmallIcon(android.R.drawable.ic_menu_more)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1, b.build())
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        @Suppress("DEPRECATION") val d = i?.getParcelableExtra<Intent>("data")
        if (i != null && d != null && proj == null) startCapture(i.getIntExtra("code", 0), d)
        addTrigger(); return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy(); stopCapture()
        trigger?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
    }

    // Invisible strip on the screen edge: swipe up on it to open the dock
    private fun addTrigger() {
        trigger?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        val left = prefs.getString("side", "right") == "left"
        val h = resources.displayMetrics.heightPixels * prefs.getInt("zone", 40) / 100
        val svc = this
        val v = object : View(svc) {
            var y0 = 0f; var done = false
            override fun onTouchEvent(e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { y0 = e.rawY; done = false }
                    MotionEvent.ACTION_MOVE -> if (!done && y0 - e.rawY > dp(48)) { done = true; performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); showDock() }
                }
                return true
            }
        }
        v.setBackgroundColor(0x01000000)
        val lp = WindowManager.LayoutParams(dp(prefs.getInt("zw", 20)), h, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM or (if (left) Gravity.START else Gravity.END)
        wm.addView(v, lp); trigger = v
    }

    // The dock always rises from the bottom with a spring, whichever side you swiped
    private fun showDock() {
        if (panel != null) return
        val pm = packageManager
        val shot = if (prefs.getBoolean("blur", true)) grab() else null
        val root = FrameLayout(this)
        val dim = View(this).apply { setBackgroundColor(0x44000000); alpha = 0f; setOnClickListener { hideDock() } }
        root.addView(dim, FrameLayout.LayoutParams(-1, -1))
        val size = dp(prefs.getInt("icon", 56))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val icons = mutableListOf<View>()
        prefs.getString("apps", "")!!.split(",").filter { it.isNotBlank() }.forEach { pkg ->
            try {
                val v = ImageView(this).apply { setImageDrawable(pm.getApplicationIcon(pkg)); setOnClickListener { launch(pkg) } }
                row.addView(v, LinearLayout.LayoutParams(size, size).apply { setMargins(dp(8), 0, dp(8), 0) }); icons.add(v)
            } catch (_: Exception) {}
        }
        if (icons.isEmpty()) row.addView(TextView(this).apply { text = "Open Magic Dock and choose apps"; setTextColor(0xFF333333.toInt()); setPadding(dp(12), dp(8), dp(12), dp(8)) })
        val sv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; addView(row); alpha = 0f; elevation = dp(12).toFloat()
            background = GradientDrawable().apply { setColor(0xCCFFFFFF.toInt()); cornerRadius = dp(34).toFloat(); setStroke(dp(1), 0x66FFFFFF) }
            outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, dp(34).toFloat()) }
            clipToOutline = true
        }
        val nb = resources.getIdentifier("navigation_bar_height", "dimen", "android").let { if (it > 0) resources.getDimensionPixelSize(it) else 0 }
        root.addView(sv, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { setMargins(dp(16), 0, dp(16), dp(24) + nb) })
        val lp = WindowManager.LayoutParams(-1, -1, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 31) { lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND; lp.blurBehindRadius = dp(20) }
        wm.addView(root, lp); panel = root; pill = sv
        sv.post {
            if (shot != null) try {
                val loc = IntArray(2); sv.getLocationOnScreen(loc)
                val x = (loc[0] / cap).coerceIn(0, shot.width - 2); val y = (loc[1] / cap).coerceIn(0, shot.height - 2)
                val crop = Bitmap.createBitmap(shot, x, y, (sv.width / cap).coerceIn(1, shot.width - x), (sv.height / cap).coerceIn(1, shot.height - y))
                sv.background = LayerDrawable(arrayOf(BitmapDrawable(resources, blur(crop, 4)), ColorDrawable(0x55FFFFFF)))
            } catch (_: Exception) {}
            val from = (sv.height + dp(120)).toFloat()
            sv.translationY = from; sv.alpha = 1f
            dim.animate().alpha(1f).setDuration(220).start()
            spr = SpringAnimation(sv, DynamicAnimation.TRANSLATION_Y, 0f).apply {
                setStartValue(from); spring.stiffness = 320f
                spring.dampingRatio = floatArrayOf(0.75f, 0.5f, 0.3f)[prefs.getInt("bounce", 1).coerceIn(0, 2)]; start()
            }
        }
    }

    private fun hideDock() {
        val r = panel ?: return; val sv = pill ?: return; panel = null; pill = null
        spr?.cancel()
        r.getChildAt(0).animate().alpha(0f).setDuration(200).start()
        sv.animate().translationY((sv.height + dp(120)).toFloat()).setDuration(240).withEndAction { try { wm.removeView(r) } catch (_: Exception) {} }.start()
    }

    // ---------- Screen capture for the blurred dock background ----------
    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); setupDisplay(); addTrigger() }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = try { mpm.getMediaProjection(code, data) } catch (_: Exception) { null } ?: return
        proj = p
        p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { proj = null; stopCapture() } }, Handler(Looper.getMainLooper()))
        setupDisplay()
    }

    private fun setupDisplay() {
        val p = proj ?: return
        val m = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
        val w = m.widthPixels / cap; val h = m.heightPixels / cap
        held?.close(); held = null; reader?.close()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2); reader = r
        r.setOnImageAvailableListener({ x -> val n = x.acquireLatestImage(); if (n != null) { held?.close(); held = n } }, Handler(Looper.getMainLooper()))
        val d = vd
        if (d == null) vd = p.createVirtualDisplay("dock", w, h, resources.displayMetrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        else { d.resize(w, h, resources.displayMetrics.densityDpi); d.surface = r.surface }
    }

    private fun stopCapture() {
        vd?.release(); vd = null; held?.close(); held = null; reader?.close(); reader = null
        proj?.let { proj = null; try { it.stop() } catch (_: Exception) {} }
    }

    private fun grab(): Bitmap? {
        val img = held ?: return null
        return try {
            val pl = img.planes[0]; val w = img.width; val h = img.height
            val pad = (pl.rowStride - pl.pixelStride * w) / pl.pixelStride
            val bmp = Bitmap.createBitmap(w + pad, h, Bitmap.Config.ARGB_8888)
            pl.buffer.rewind(); bmp.copyPixelsFromBuffer(pl.buffer)
            Bitmap.createBitmap(bmp, 0, 0, w, h)
        } catch (_: Exception) { null }
    }

    private fun blur(src: Bitmap, r: Int): Bitmap {
        val w = src.width; val h = src.height; var px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        repeat(3) { px = box(px, w, h, r, true); px = box(px, w, h, r, false) }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
    private fun box(p: IntArray, w: Int, h: Int, r: Int, horiz: Boolean): IntArray {
        val o = IntArray(p.size); val n = if (horiz) w else h; val m = if (horiz) h else w
        for (j in 0 until m) for (i in 0 until n) {
            var rs = 0; var gs = 0; var bs = 0
            for (k in -r..r) { val q = (i + k).coerceIn(0, n - 1); val c = if (horiz) p[j * w + q] else p[q * w + j]
                rs += (c shr 16) and 255; gs += (c shr 8) and 255; bs += c and 255 }
            val d = 2 * r + 1
            o[if (horiz) j * w + i else i * w + j] = (0xFF shl 24) or ((rs / d) shl 16) or ((gs / d) shl 8) or (bs / d)
        }
        return o
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it) }
        hideDock()
    }
}
