package com.example.magicdock

import android.app.*
import android.content.*
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var col: LinearLayout
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun tv(t: String, sz: Float = 16f, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
    private fun restart() { if (p.getBoolean("on", false)) startDock(this) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        p = getSharedPreferences("dock", MODE_PRIVATE)
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(48)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF101418.toInt()); addView(col) })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    }
    override fun onResume() { super.onResume(); build() }

    private fun begin() {
        if (p.getBoolean("blur", true)) {
            val mp = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION") startActivityForResult(mp.createScreenCaptureIntent(), 7)
        } else startDock(this)
    }
    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 7) { if (res == RESULT_OK && d != null) startDock(this, res, d) else startDock(this) }
    }

    private fun build() {
        col.removeAllViews()
        col.addView(tv("Magic Dock", 26f))
        col.addView(tv("Swipe up along the screen edge to open your dock.", 14f, 0xFFAAB4BE.toInt()).apply { setPadding(0, dp(4), 0, dp(16)) })
        if (!Settings.canDrawOverlays(this)) {
            col.addView(Button(this).apply { text = "Allow display over other apps"
                setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
            return
        }
        col.addView(Switch(this).apply {
            text = "Enable dock"; textSize = 18f; setTextColor(Color.WHITE); isChecked = p.getBoolean("on", false); setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, b -> p.edit().putBoolean("on", b).apply()
                if (b) begin() else stopService(Intent(this@MainActivity, DockService::class.java)) }
        })
        col.addView(Button(this).apply {
            text = "Swipe side: ${p.getString("side", "right")}"
            setOnClickListener { val n = if (p.getString("side", "right") == "left") "right" else "left"; p.edit().putString("side", n).apply(); text = "Swipe side: $n"; restart() }
        })
        col.addView(Switch(this).apply {
            text = "Blurred background (screen capture)"; textSize = 16f; setTextColor(Color.WHITE); isChecked = p.getBoolean("blur", true); setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, b -> p.edit().putBoolean("blur", b).apply()
                if (p.getBoolean("on", false)) { stopService(Intent(this@MainActivity, DockService::class.java)); if (b) begin() else startDock(this@MainActivity) } }
        })
        val names = listOf("Soft spring", "Bouncy spring", "Very bouncy spring")
        col.addView(Button(this).apply {
            text = names[p.getInt("bounce", 1)]
            setOnClickListener { val n = (p.getInt("bounce", 1) + 1) % 3; p.edit().putInt("bounce", n).apply(); text = names[n] }
        })
        slider("Swipe area height", "zone", 15, 80, 40, "%"); slider("Swipe area width", "zw", 12, 40, 20, "dp"); slider("Icon size", "icon", 40, 80, 56, "dp")
        val n = p.getString("apps", "")!!.split(",").count { it.isNotBlank() }
        col.addView(Button(this).apply { text = "Choose dock apps ($n selected)"; setOnClickListener { pickApps() } })
        col.addView(tv("Apps appear in the order you tick them.", 13f, 0xFFAAB4BE.toInt()))
    }

    private fun slider(t: String, k: String, lo: Int, hi: Int, d: Int, u: String) {
        val lab = tv("$t: ${p.getInt(k, d)}$u").apply { setPadding(0, dp(14), 0, 0) }
        col.addView(lab)
        col.addView(SeekBar(this).apply {
            max = hi - lo; progress = p.getInt(k, d) - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, pr: Int, user: Boolean) { lab.text = "$t: ${pr + lo}$u"; p.edit().putInt(k, pr + lo).apply() }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { restart() }
            })
        })
    }

    private fun pickApps() {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }.sortedBy { it.first.lowercase() }
        val sel = p.getString("apps", "")!!.split(",").filter { it.isNotBlank() }.toMutableList()
        val checked = BooleanArray(list.size) { list[it].second in sel }
        AlertDialog.Builder(this).setTitle("Dock apps")
            .setMultiChoiceItems(list.map { it.first }.toTypedArray(), checked) { _, i, b -> if (b) sel.add(list[i].second) else sel.remove(list[i].second) }
            .setPositiveButton("Save") { _, _ -> p.edit().putString("apps", sel.joinToString(",")).apply(); build() }
            .setNegativeButton("Cancel", null).show()
    }
}
